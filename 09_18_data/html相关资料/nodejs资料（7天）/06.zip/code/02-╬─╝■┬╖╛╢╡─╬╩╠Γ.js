var fooIndex = require('./foo/index')
